### WebStackPage-ThinkPHP5
是一个免费开源的导航项目
前端基于[WebStackPage](https://github.com/WebStackPage/WebStackPage.github.io "WebStackPage")开发
后端基于ThinkPHP5开发

- 用户可以在后台自定义添加分类菜单
- 用户可以在后台添加书签链接及图片
- 一键设置前端显示的站点信息/Logo等
- 目前处于开发阶段,现有的基础功能已经实现,后续功能敬请期待...

放一张viggo大佬原有的截图
[![](https://camo.githubusercontent.com/41111c4c1d9922982f380566e6a2f8415204c52c/687474703a2f2f7777772e776562737461636b2e63632f6173736574732f696d616765732f707265766965772e676966)](https://camo.githubusercontent.com/41111c4c1d9922982f380566e6a2f8415204c52c/687474703a2f2f7777772e776562737461636b2e63632f6173736574732f696d616765732f707265766965772e676966)


------------

**测试数据已经上传!**

- 后台访问路由
`http://domain/home/index.html`
- 初始登录账户密码
`admin 123456`
- 登录之后请在后台右上角及时修改登录密码

**暂时不提供演示站,大佬们按照tp5的部署方式部署访问就好!
数据库文件在根目录下**`fydh.sql`

### PS:本人技术水平有限, 大牛勿喷 谢谢!
如果有什么好的建议或想法 请通过邮箱联系我: **admin@fyovo.com**

By : 风影